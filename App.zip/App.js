// src/App.js
import React, { useState } from 'react';

function App() {
  const [nota1, setNota1] = useState('');
  const [nota2, setNota2] = useState('');
  const [nota3, setNota3] = useState('');
  const [media, setMedia] = useState(null);

  const calcularMedia = () => {
    const n1 = parseFloat(nota1);
    const n2 = parseFloat(nota2);
    const n3 = parseFloat(nota3);

    if (!isNaN(n1) && !isNaN(n2) && !isNaN(n3)) {
      const mediaCalculada = (n1 + n2 + n3) / 3;
      setMedia(mediaCalculada);
    } else {
      setMedia(null);
    }
  };

  return (
    <div className="App">
      <h1>Calculadora de Média de Notas</h1>
      <div>
        <label>
          Nota 1:
          <input
            type="number"
            step="0.1"
            value={nota1}
            onChange={(e) => setNota1(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Nota 2:
          <input
            type="number"
            step="0.1"
            value={nota2}
            onChange={(e) => setNota2(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Nota 3:
          <input
            type="number"
            step="0.1"
            value={nota3}
            onChange={(e) => setNota3(e.target.value)}
          />
        </label>
      </div>
      <button onClick={calcularMedia}>Calcular Média</button>
      {media !== null && (
        <div>
          <h2>Média: {media.toFixed(2)}</h2>
        </div>
      )}
    </div>
  );
}

export default App;
